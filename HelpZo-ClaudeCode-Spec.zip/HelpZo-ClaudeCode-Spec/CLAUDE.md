# CLAUDE.md — HelpZo Mobile Apps (build instructions for Claude Code)

You are building **two React Native (Expo) mobile apps** that must match the
provided designs **pixel-for-pixel**. The final deliverable Aman needs is an
installable **Android APK**.

## What this folder contains
- `design-system.md` — colors, typography, spacing, shared components. **Read this first and build the theme + shared components before any screen.**
- `navigation.md` — tab bars and screen flow for both apps.
- `customer-app/` — 10 screen specs (customer-facing app).
- `provider-app/` — 22 screen specs (service-provider app).
- `assets/customer/` and `assets/provider/` — the reference screenshots. **Open the matching PNG while building each screen and match it exactly.**

Each screen spec file is named to match its screenshot (e.g.
`customer-app/03-home.md` ↔ `assets/customer/03_home.png`).

## Tech stack (use exactly this)
- **Expo** (SDK latest stable), **TypeScript**.
- **expo-router** for file-based navigation (tabs + stacks).
- **Styling:** `StyleSheet` with a central `theme/` (colors, spacing, typography) — or NativeWind if you prefer utility classes. Keep tokens centralized either way.
- **Icons:** `lucide-react-native` (fallback `@expo/vector-icons` Ionicons).
- **Fonts:** Inter via `expo-font` / `@expo-google-fonts/inter`.
- **Maps:** for the "En Route" screen use `react-native-maps`; if map key setup is a blocker, render a static map image placeholder that matches the design.
- **State:** local component state / simple context. No backend in phase 1 — all data is the mock data written into each screen spec.

## Build order
1. `theme/` tokens from `design-system.md` (colors, typography, spacing, radii).
2. Shared components from `design-system.md §5` (AppHeader, PrimaryButton, SuccessButton, OutlineButton, Chip, StatusPill, Card, Avatar, RatingRow, ServiceIconCircle, BottomTabBar, TextField, StepIndicator, ProgressBar, JobProgress, StatTile, IconTile).
3. Customer app screens 01→10.
4. Provider app screens 01→22.
5. Wire navigation per `navigation.md`.
6. Verify each screen against its screenshot.

## Two apps, one repo
Keep a single Expo repo with a shared design layer and two route groups:

```
app/
  (customer)/        # customer app routes
  (provider)/        # provider app routes
components/          # shared UI components
theme/              # colors, typography, spacing
mock/               # static data used by screens
assets/             # icons, images, fonts
```

Add a simple **role switcher** on first launch (or two separate Expo build
profiles) so each app can be built independently. For the APK, Aman will most
likely want the **customer app** and the **provider app** as **two separate
APKs** — keep the entry points cleanly separable.

## Producing the APK
Use EAS Build (cloud) — no Android Studio needed:
```
npm i -g eas-cli
eas login
eas build:configure
# build an installable APK (not AAB) using a preview profile:
eas build -p android --profile preview
```
In `eas.json`, the `preview` profile should set:
```json
{ "build": { "preview": { "android": { "buildType": "apk" } } } }
```
EAS returns a downloadable `.apk` link. For two apps, run two builds with
different `app.json` (name, slug, package id e.g. `com.helpzo.customer` and
`com.helpzo.provider`).

## Fidelity rules (important)
- Match the reference screenshot exactly: layout order, spacing, colors, text content, icon choice, corner radius, button colors.
- Use the **exact mock text** from each spec (names, prices, ratings, addresses, timestamps) so the built screen is indistinguishable from the design.
- Header style (blue gradient vs white) is specified per screen — follow it.
- The status-bar mock `9:41` in designs is just the phone status bar — do not hardcode it; let the device show real time.
- When in doubt, the screenshot wins.
