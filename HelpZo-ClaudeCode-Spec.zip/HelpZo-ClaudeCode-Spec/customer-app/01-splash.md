# Customer 01 — Splash Screen
Reference: `assets/customer/01_splash.png` · Route: `/(customer)/splash` (initial)

**Purpose:** Brand splash on launch. Auto-navigates to Login after ~2s.

**Background:** full-screen deep-blue gradient (`primaryDeep #062B7A` → `primary`), with a faint large house outline watermark centered.

**Layout (centered column):**
1. Top ~30%: **HelpZo logo** (house + wrench mark) above the wordmark **HelpZo** — "Help" white, "Zo" green `#22B24C`, `display` size, weight 800.
2. Under wordmark: tagline **"Your Problem  Our Priority"** — white, 14, letter-spaced, with a small dot separator between the two phrases.
3. Middle: illustration of a **male technician in blue overalls + cap holding a wrench** (friendly cartoon style), sitting over a faint house silhouette.
4. Lower: **"Find Trusted Local"** (white, 20, 700) + **"Service Providers"** (green, 20, 700) on next line, centered.
5. Below that: a row of 3 trust chips inline — `✓ Fast` · `✓ Safe` · `✓ Reliable` — small white text with tiny green check/badge icons, separated by dots.
6. Bottom: a thin rounded **loading bar** — green fill on a translucent track (indeterminate/progress).

**Behavior:** after 2s (or when fonts load) → replace to Login (02). No back.
