# Customer 10 — Profile & Settings
Reference: `assets/customer/10_profile.png` · Route: `/(customer)/(tabs)/profile` · **Tab: Profile**

**Purpose:** Customer account, profile completeness, menu, logout.

**Body (white, scroll, padding 16):**
1. **Profile header row:** round avatar (photo) left; **"Pradip Parmar"** (h2 navy 700) + **"+91 98765 43210"** (secondary) stacked; **pencil/edit** icon on the right.
2. **Complete Profile card/row:** small circular progress glyph + **"Complete Profile"** (navy 600) + **"80%"** right. Below: green **ProgressBar** at 80%.
3. **Menu list** (Card containing rows; each row: leading outline icon, label navy 600, chevron-right; hairline dividers):
   - calendar — **"My Bookings"** → (07)
   - heart — **"Saved Providers"** → (08)
   - help-circle — **"Help & Support"**
   - file — **"Terms & Conditions"**
   - lock — **"Privacy Policy"**
   - info — **"About HelpZo"**
4. **Logout button:** full-width **OutlineButton** with `danger` red border + red **"Logout"** text (with log-out icon).

**Bottom tab bar:** Profile active (blue).
