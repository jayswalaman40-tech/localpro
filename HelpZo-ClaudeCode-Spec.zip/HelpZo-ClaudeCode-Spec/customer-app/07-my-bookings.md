# Customer 07 — My Bookings
Reference: `assets/customer/07_my_bookings.png` · Route: `/(customer)/(tabs)/bookings` · **Tab: Bookings**

**Purpose:** List customer's bookings by status.

**Header (white):** back `‹` + **"My Bookings"** (navy 700).

**Filter tabs (`Chip` row):** **`Upcoming`** (selected, blue) · `Completed` · `Cancelled`.

**Body — list of booking rows** (each row: avatar left, details middle, status pill right; hairline divider between):
Each row: round avatar photo, then **Service** (h3 navy), **Provider name** (body), a line **"DD Mon YYYY • time"** (secondary), map-pin **"area, Ahmedabad"** (secondary). Right side: a `StatusPill`.

**Mock data:**
1. **AC Repair** · Suresh Kumar · 12 Sep 2025 • 5:00 PM · Bopal, Ahmedabad · pill **Confirmed** (green)
2. **Electrician** · Ajay Sharma · 15 Sep 2025 • 4:00 PM · Satellite, Ahmedabad · pill **Pending** (orange)
3. **Carpenter** · Mahesh Patel · 18 Sep 2025 • 11:00 AM · Thaltej, Ahmedabad · pill **Confirmed** (green)
4. **Painter** · Raju Singh · 20 Sep 2025 • 3:00 PM · Vastrapur, Ahmedabad · pill **Pending** (orange)

**Bottom tab bar:** Bookings active (blue).
