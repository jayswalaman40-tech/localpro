# Customer 09 — Notifications
Reference: `assets/customer/09_notifications.png` · Route: `/(customer)/notifications`

**Purpose:** Customer notification feed.

**Header (white):** back `‹` + **"Notifications"** (navy 700).

**Body — list of notification rows** (each: round colored icon-circle left, title + 2-line body middle, "time ago" top-right; hairline divider):
Each row: colored circle w/ white glyph; **Title** (h3 navy); body (secondary, up to 2 lines); **time** (tertiary, top-right).

**Mock data:**
1. green check circle — **"Service Request Accepted"** — "Ramesh Singh has accepted your AC repair request." — 2m ago
2. blue calendar circle — **"Booking Confirmed"** — "Your booking for electrician service is confirmed for 15 Sep 2025." — 1h ago
3. orange tag circle — **"New Offer"** — "Get 15% OFF on your first AC service booking!" — 3h ago
4. orange bell circle — **"Reminder"** — "Your appointment is tomorrow at 5:00 PM." — 1d ago
5. orange star circle — **"Review Request"** — "Please share your experience with Ramesh Singh." — 1d ago

**Bottom tab bar visible:** here the **Profile** tab shows active/blue in the reference (reached via profile area) — match screenshot: Home · Bookings · Saved · **Profile (blue)**.
