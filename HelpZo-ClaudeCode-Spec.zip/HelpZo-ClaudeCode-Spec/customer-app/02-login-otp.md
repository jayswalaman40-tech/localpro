# Customer 02 — Login / OTP
Reference: `assets/customer/02_login_otp.png` · Route: `/(customer)/login`

**Purpose:** Phone-number login entry. "Get OTP" starts verification.

**Background:** white. Bottom third has soft green→blue **wave** decoration (layered translucent curves).

**Layout (top to bottom, screen padding 16):**
1. Back chevron `‹` top-left (navy).
2. Centered **HelpZo logo** mark + wordmark ("Help" blue, "Zo" green), medium size, ~top 15%.
3. **"Login to Continue"** — centered, `h2` navy 700.
4. **Phone TextField** (component `TextField`): rounded 16, 1px border, height 56. Left: 🇮🇳 India flag + `+91` + a thin vertical divider, then placeholder **"Enter Mobile Number"** (secondary). White fill.
5. **PrimaryButton "Get OTP"** — full width, blue, radius 16, height 52.
6. Legal text centered, small secondary: **"By continuing, you agree to our"** then next line **"Terms & Conditions  •  Privacy Policy"** (both blue links).
7. Bottom (above safe area, over the wave): **"New here? Create Account"** — "New here?" secondary, "Create Account" green 700.

**Behavior:** "Get OTP" → OTP verify screen (can be a simple modal/next step; not in the 10 provided — stub it) → Home (03). Back → Splash/exit.
