# Customer 05 — Provider Profile
Reference: `assets/customer/05_provider_profile.png` · Route: `/(customer)/provider/[id]`

**Purpose:** Full provider detail with reviews; book or call.

**Top hero:** full-width **cover photo** of the provider (technician holding wrench). Overlaid:
- top-left: circular translucent back `‹` button.
- top-right: circular white button with a **red filled heart** (saved state).

**White content sheet** (overlaps hero bottom, rounded top 24, scrolls):
1. **"Ramesh Singh"** (h2 navy 700) + blue verified check. On the right of this row: green **"✓ Verified"** pill.
2. `RatingRow` **★ 4.8 (124 reviews)**.
3. Meta line: **"Plumber • 5+ years exp • Ahmedabad"** (secondary).
4. **"₹200 onwards"** (price, navy 700).
5. **Description** paragraph (secondary): *"Experienced plumber with 5+ years of experience in home and commercial plumbing services. Quick & reliable service guaranteed."*
6. **Feature row** — 3 items in a light rounded panel, each an outline icon + 2-line label:
   - clock **"On Time Service"**
   - shield-check **"Verified Provider"**
   - headset **"Customer Satisfaction"**
7. **SectionTitle "Reviews & Ratings"** + "See All" (blue).
8. **Review item:** small avatar, **"Neha Patel"**, 5 gold stars + **"5.0"**, date **"12 Sep 2025"** right; text *"Very professional and quick service. Highly recommended!"*

**Sticky bottom bar** (two buttons side by side):
- Green **SuccessButton "Book Now"** (flex 2) → Book Service (06).
- Green **OutlineButton "Call"** (flex 1, green border/text).
