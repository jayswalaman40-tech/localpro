# Customer 08 — Saved Providers
Reference: `assets/customer/08_saved.png` · Route: `/(customer)/(tabs)/saved` · **Tab: Saved**

**Purpose:** Bookmarked providers list.

**Header (white):** back `‹` + **"Saved Providers"** (navy 700).

**Body — list rows** (round avatar left, text middle, red filled heart right; hairline divider):
Each: **Name** (h3 navy), **"Category • rating"** (secondary), **"X km away"** (secondary). Right: **red filled heart** (tap to unsave).

**Mock data:**
1. Ramesh Singh · Plumber • 4.8 · 2.1 km away
2. Jayesh Patel · Electrician • 4.6 · 3.5 km away
3. Imran Khan · AC Repair • 4.5 · 4.8 km away
4. Mukesh Yadav · Carpenter • 4.3 · 5.2 km away
5. Sunil Sharma · Painter • 4.2 · 6.1 km away

**Bottom tab bar:** Saved active (blue).
