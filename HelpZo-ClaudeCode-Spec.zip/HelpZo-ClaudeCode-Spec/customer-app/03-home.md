# Customer 03 — Home
Reference: `assets/customer/03_home.png` · Route: `/(customer)/(tabs)/home` · **Tab: Home**

**Purpose:** Customer landing. Search, popular services grid, top providers.

**Header (light variant, white bg):**
- Left: **HelpZo** wordmark (small), and below it a location row: green map-pin + **"Ahmedabad"** (navy 600) + chevron-down.
- Right: **bell** icon with small red unread dot → Notifications (09).

**Body (scroll):**
1. **Promo / search banner card** — blue gradient rounded card (radius 20), with:
   - Heading **"Need a Service?"** (white, 22, 700) + **"We're here to help!"** (white, 14).
   - A cut-out photo of a smiling technician on the right.
   - A white **search field** overlapping the bottom of the card: placeholder **"Search for service (e.g. Plumber)"**, with a green round **search** button on the right end.
2. **SectionTitle "Popular Services"** + "See All" (blue) right.
3. **Service grid** — 2 rows × 4 = 8 `ServiceIconCircle` items with labels:
   Row 1: **Plumber** (blue drop), **Electrician** (amber bolt), **AC Repair** (sky snowflake), **Carpenter** (brown tools).
   Row 2: **Painter** (magenta roller), **Cleaning** (green broom), **Home Repair** (orange house), **More** (grey 3-dots).
   - Icon circle ~60, colors from design-system table. Labels `body` navy centered.
4. **SectionTitle "Top Providers Near You"** + "See All" right.
5. **Provider card** (Card):
   - Left: square avatar (radius 16) photo of a technician.
   - Right column: **"Ramesh Singh"** + blue verified check; `RatingRow` **★ 4.8 (124 reviews)**; map-pin **"2.1 km away"**; **"Plumber • 5+ years exp"** (secondary).
   - Full-width green **SuccessButton "View Profile"** at the bottom of the card (pill radius 20) → Provider Profile (05).

**Bottom tab bar:** Home (active, blue) · Bookings · Saved · Profile.

**Data:** use the exact text above.
