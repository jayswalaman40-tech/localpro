# Customer 06 — Book Service
Reference: `assets/customer/06_book_service.png` · Route: `/(customer)/book/[providerId]`

**Purpose:** Choose date/time, confirm a booking.

**Header (white):** back `‹` + **"Book Service"** (navy 700).

**Body (scroll, padding 16):**
1. **Provider summary Card:** round avatar + **"Ramesh Singh"** + blue check; `RatingRow` ★4.8 (124 reviews); **"Plumber • ₹200 onwards"** (secondary).
2. **"Select Date & Time"** (h2).
3. **Date selector** — 3 `Chip`-style cards in a row, each two-line (day label + date):
   - **Today / 12 Sep** (selected — light blue fill, blue border).
   - **Tomorrow / 12 Sep** (unselected).
   - **Mon / 14 Sep** (unselected).
4. **Time slots** — pill buttons wrapping (2 per row):
   `9:00 AM` · `11:00 AM` · **`2:00 PM`** (selected, solid blue, white text) · `5:00 PM` · `7:00 PM`.
   Unselected = white pill, border, navy text.
5. **"Service Address"** (h2). Row: map-pin + **"Bopal, Ahmedabad"** (navy) with **"Change"** link (blue) on the right.
6. **"Additional Note (Optional)"** (h2). Multiline `TextField`, placeholder **"Any specific requirement?"**.

**Sticky bottom:** full-width green **SuccessButton "Confirm Booking"** → success toast/screen → My Bookings (07).
