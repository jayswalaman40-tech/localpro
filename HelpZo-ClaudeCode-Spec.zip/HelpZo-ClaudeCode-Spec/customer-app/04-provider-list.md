# Customer 04 — Service Provider List
Reference: `assets/customer/04_provider_list.png` · Route: `/(customer)/providers?category=Plumber`

**Purpose:** List of providers for a chosen category, filterable.

**Header (white):** back `‹` + title **"Plumber"** (navy 700). Below title: map-pin + **"Ahmedabad"** + chevron-down (secondary).

**Filter row (`Chip` row, horizontal scroll):**
`All` (selected — blue pill, white text) · `Top Rated` · `Nearest` · `Price Low...` (unselected — white pill, border, secondary text).

**Body — vertical list of provider `Card`s** (each ~ same layout):
Each card:
- Left: square avatar (radius 16) photo.
- Right: **Name** + blue verified check; `RatingRow` **★ rating (N reviews)**; map-pin **"X km away"**; **"₹NNN onwards"** (price, navy 700).
- Top-right of card: outline **heart** (save toggle).
- Full-width green **SuccessButton "Book Now"** (pill) at card bottom → Provider Profile (05) / Book Service (06).

**Mock data (4 cards):**
1. Ramesh Singh · ★4.8 (124 reviews) · 2.1 km away · ₹200 onwards
2. Jayesh Patel · ★4.6 (98 reviews) · 3.5 km away · ₹250 onwards
3. Imran Khan · ★4.5 (76 reviews) · 4.8 km away · ₹220 onwards
4. Mukesh Yadav · ★4.3 (54 reviews) · 5.2 km away · ₹180 onwards

Scrolls under a fixed header. No bottom tab (stack screen).
