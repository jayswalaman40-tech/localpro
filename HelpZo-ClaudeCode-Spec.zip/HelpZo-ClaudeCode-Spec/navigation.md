# Navigation — both apps

## Customer App

**Bottom tab bar (4 tabs)** — visible on Home, Bookings, Saved, Profile:
`Home` (house) · `Bookings` (clipboard) · `Saved` (heart) · `Profile` (person).
Active tab = blue filled icon + blue label.

### Flow
```
Splash (01) ──auto 2s──▶ Login/OTP (02) ──▶ Home (03)   [tab: Home]

Home (03)
  ├─ tap category / See All ▶ Provider List (04)
  ├─ tap provider "View Profile" ▶ Provider Profile (05)
  ├─ bell icon ▶ Notifications (09)
  └─ tab bar ▶ Bookings(07) / Saved(08) / Profile(10)

Provider List (04) ── tap card / Book Now ▶ Provider Profile (05) or Book Service (06)
Provider Profile (05) ── "Book Now" ▶ Book Service (06)
Book Service (06) ── "Confirm Booking" ▶ success → My Bookings (07)
Profile (10) ── rows ▶ My Bookings (07) / Saved (08) / Help / T&C / etc.
```
- Screens 04, 05, 06, 09 are **stack screens** with a back chevron (not tabs).
- 03 Home, 07 Bookings, 08 Saved, 10 Profile are **tab screens**.

## Provider App

**Bottom tab bar — label set changes by section but keep it 5 items.**
Primary set: `Home` · `Leads` · `Jobs` · `Earnings` · `Profile`.
On some screens the set shows `Home · Schedule · Jobs · Earnings · Profile` and
`Reviews` / `Support` / `Settings`/`Notifications` appear as the active 5th item
when those screens are reached from Profile/menu. Implement one tab bar
component and pass the active route; match the label set shown in each
screenshot.

### Flow
```
Splash (01) ──▶ Login/OTP (02)
  ├─ existing user ▶ Active Jobs / Home (06)
  └─ "Register as Provider" ▶ Registration wizard:
        Basic (03) ▶ Details (19) ▶ Documents (20) ▶ Submitted (21) ▶ Go to Dashboard (06)
     (Service & Skills (04) and Document Verification (05) are the detail
      screens reached from the Details/Documents steps.)

Dashboard / Active Jobs (06)  [tab: Jobs]
  ├─ Leads tab ▶ New Service Requests (07)
  │     └─ tap a lead ▶ Job Details (08) ▶ "Accept Job"
  ├─ active job "Update Status" / Start Job ▶ En Route (09)
  │     └─ "Arrived at Location" ▶ Job In Progress (10)
  │           └─ "Complete Job" ▶ Job Completed (11)
  ├─ Earnings tab ▶ Earnings (12)  (Withdraw)
  ├─ Schedule tab ▶ My Schedule (14)
  ├─ chat icon on a job ▶ Chat with Customer (15)
  └─ Profile tab ▶ My Profile (13)
        ├─ ▶ Reviews & Ratings (16)
        ├─ ▶ Help & Support (17)
        ├─ ▶ Settings (18)
        └─ ▶ Notifications (22)  (also from bell)
```

### Registration wizard mapping (StepIndicator 1-2-3-4)
- Step 1 **Basic** → `03-registration-basic.md` (Personal Details)
- Step 2 **Details** → `19-registration-details.md` (Service Details) + `04-service-and-skills.md` (skill picker)
- Step 3 **Documents** → `20-registration-documents.md` (upload) + `05-document-verification.md` (verified state)
- Step 4 **Complete** → `21-registration-submitted.md`
