# Provider 04 — Select Service & Skills
Reference: `assets/provider/04_Service_and_Skills.png` · Route: `/(provider)/register/skills`

**Purpose:** Provider picks the services they offer + experience. (Reached from Details step / "Select Service Category".)

**Header (blue gradient):** back `‹` + **"Select Your Service & Skills"** (white 700) + subtitle **"Choose the services you provide"**.

**Body (white sheet):**
1. **Search field:** search icon + placeholder **"Search service..."** (rounded 16, `bgMuted` fill).
2. **Service grid** — 3 columns × 3 rows of `ServiceIconCircle` (selectable; tap toggles a blue ring/check):
   Row 1: **Plumber** (blue), **Electrician** (amber bolt), **AC Repair** (sky snowflake).
   Row 2: **Carpenter** (brown tools), **Painter** (magenta roller), **Cleaning** (green broom).
   Row 3: **Home Repair** (orange house), **More** (grey 3-dots).
   Labels navy 600 centered.
3. **"Experience (Years)"** (h2 navy).
4. Row of 4 selectable pills: **`< 1`** · **`1 - 3`** · **`3 - 5`** · **`5+`** (white pills, border; selected → blue).
5. **PrimaryButton "Next"** (blue).
