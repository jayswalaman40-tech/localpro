# Provider 13 — My Profile
Reference: `assets/provider/13_My_Profile.png` · Route: `/(provider)/(tabs)/profile` · **Tab: Profile**

**Purpose:** Provider account hub.

**Header (blue gradient):** **"My Profile"** (white 700) + subtitle **"Manage your account and settings"** + a white **"✎ Edit Profile"** outline pill top-right.

**Body (white sheet, scroll):**
1. **Profile card:** round avatar (photo) with a small green **online dot**; **"Aman Sharma"** (h2 navy 700); **"Service Professional"** (secondary); `RatingRow` **★ 4.8 (124 reviews)**; map-pin **"Ahmedabad, Gujarat"**; blue shield-check **"ID Verified"**. Top-right of card: green **"● Online"** pill with chevron (status toggle).
2. **StatTile row (4):** briefcase **"124 / Jobs Completed"** · star **"4.8 / Rating"** · people **"96 / Happy Customers"** · rupee **"₹32,450 / Total Earnings"**.
3. **Menu list** (Card of rows; leading icon, title 600 + subtitle secondary, chevron-right):
   - user — **"Personal Information"** / "Name, phone, address, documents"
   - settings — **"Service Categories"** / "Manage your services"
   - wallet — **"Bank & Payouts"** / "Manage payment methods"
   - file — **"My Documents"** / "ID proof, certifications"
   - bell — **"Notification Settings"** / "Manage your alerts"
   - headset — **"Help & Support"** / "Get help or contact us" → (17)
   - shield — **"Privacy & Security"** / "Manage your data"
   - log-out (red) — **"Logout"** / "Sign out from your account"

**Bottom tab bar:** Home · Leads · Jobs · Earnings · **Profile (active, blue)**.
