# Provider 07 — New Service Requests (Leads)
Reference: `assets/provider/07_New_Service_Requests_Leads.png` · Route: `/(provider)/(tabs)/leads` · **Tab: Leads**

**Purpose:** Incoming leads to accept/reject.

**Header (blue gradient):** back `‹` + **"New Service Requests"** (white 700) + a **filter** (funnel) icon on the right.

**Body (white sheet):**
1. **Segment tabs (`Chip` row):** **`All (12)`** (selected blue) · `Pending (8)` · `Accepted (3)`.
2. **Lead cards** (list). Each card:
   - Leading `ServiceIconCircle` (category color).
   - **Service** (h3 navy).
   - map-pin **"Ahmedabad - Area"** (secondary); clock **"X km • Today, time"** (secondary).
   - **Price range** in green 700: **"₹NNN - ₹NNN"**.
   - Two buttons in a row: green **SuccessButton "Accept"** + **OutlineButton "Reject"** (red border/text).

**Mock cards:**
1. **AC Repair** — Ahmedabad - Satellite — 2.1 km • Today, 5:00 PM — ₹300 - ₹500 — Accept / Reject
2. **Plumbing** — Ahmedabad - Bodakdev — 3.4 km • Today, 4:30 PM — ₹200 - ₹400 — Accept / Reject
3. **Electrician** — Ahmedabad - Thaltej — 4.2 km • Today, 6:00 PM — ₹250 - ₹450 — Accept / Reject
4. **Carpenter** — Ahmedabad - Nikol — 1.8 km • Tomorrow, 10:00 AM — ₹400 - ₹800 — Accept / Reject

Tapping a card → Job Details (08).

**Bottom tab bar:** Home · **Leads (active, blue)** · Jobs · Earnings · Profile.
