# Provider 08 — Job Details
Reference: `assets/provider/08_Job_Details.png` · Route: `/(provider)/job/[id]/details`

**Purpose:** Full lead/job detail; accept or reject.

**Header (blue gradient):** back `‹` + **"Job Details"** (white 700) + subtitle **"View job details and accept the request"** + a **⋯** (more) icon top-right.

**Body (white sheet, scroll):**
1. **Job summary Card:**
   - Leading `ServiceIconCircle` (blue AC icon) + **"AC Repair"** (h2 navy) + right-top green pill **"New Request"**.
   - Sub-title **"Split AC not cooling"** (secondary).
   - Rows: person **"Rahul Sharma"**; phone **"+91 98765 43210"** + WhatsApp green icon; map-pin **"Bodakdev, Ahmedabad"**; clock **"Today, 5:00 PM"**; rupee **"₹300 - ₹500 (Estimated)"**.
2. **"Service Description"** (h3) + paragraph: *"My split AC is not cooling properly. It turns on but gives less cooling. Please bring necessary tools."*
3. **Two info tiles** side by side (rounded, tinted): building icon **"Property Type / 2 BHK Apartment"**; wrench icon **"Preferred Brand / Voltas"**.
4. **"Customer Photos (2)"** (h3) + **"View All ›"** link right. Two thumbnail images (indoor AC unit + outdoor Voltas unit), rounded 12.
5. **"Location"** (h3) + a **map preview** card with a red pin, label **"Bodakdev, Ahmedabad"**, and a white **"Open in Maps"** button (nav icon) overlaid.

**Sticky bottom bar (two buttons):** **OutlineButton "Reject"** (red) + green **SuccessButton "Accept Job"** → moves job to Active (06) / En Route (09).
