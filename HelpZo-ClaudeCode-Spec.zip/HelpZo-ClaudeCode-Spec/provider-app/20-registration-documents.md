# Provider 20 — Registration: Documents (Step 3)
Reference: `assets/provider/20_Registration_Documents.png` · Route: `/(provider)/register/documents`

**Purpose:** Wizard step 3 — upload KYC docs (upload state, before verification).

**Header (blue gradient):** back `‹` + **"Register as Provider"** (white 700) + subtitle **"Join HelpZo and get more work"**.

**Body (white sheet):**
1. **StepIndicator:** 1 Basic (done) — 2 Details (done) — **3 Documents** (active blue) — 4 Complete.
2. **"Upload Documents"** (h2) + **"Upload your KYC documents to get verified"** (secondary).
3. Four **document rows** (Card): leading `IconTile` (tinted) + title (h3) + subtitle (secondary) + right-side green **"⬆ Upload"** outline button:
   - blue id-card — **"Aadhaar Card"** / "Front & Back" — Upload
   - blue id-card — **"PAN Card"** / "Front" — Upload
   - avatar — **"Selfie with Aadhaar"** / "Live Photo" — Upload
   - amber bank — **"Bank Details"** / "Cancel Cheque / Passbook" — Upload
4. **Reassurance banner** (light green): green shield-check + **"Your Documents are Safe / We keep your documents secure and private."**
5. **PrimaryButton "Next"** (blue) → Submitted (21).

> Note: screen 05 (Document Verification) is the *verified* version of this list; use the same row layout, swapping the Upload button for a green "Verified" pill.
