# Provider 03 — Registration: Basic (Step 1)
Reference: `assets/provider/03_Provider_Registration_Basic.png` · Route: `/(provider)/register/basic`

**Purpose:** Registration wizard step 1 — personal details.

**Header (blue gradient):** back `‹` + **"Register as Provider"** (white 700) + subtitle **"Join HelpZo and get more work"** (white, lighter). White content sheet with rounded top overlaps below.

**Body:**
1. **StepIndicator** (1-4): **1 Basic** active (blue filled), 2 Details, 3 Documents, 4 Complete (grey).
2. **"Personal Details"** (h2 navy).
3. Three `TextField`s, each with leading rounded icon tile, a bold label and placeholder/value:
   - user icon — **"Full Name"** / placeholder "Enter your full name"
   - phone icon — **"Mobile Number"** / value "+91 98765 43210" (secondary)
   - mail icon — **"Email Address"** / placeholder "Enter your email (optional)"
4. **PrimaryButton "Next"** (blue) → Details step (19).
5. Centered footer: **"Already have an account?  Login"** ("Login" blue 700).
