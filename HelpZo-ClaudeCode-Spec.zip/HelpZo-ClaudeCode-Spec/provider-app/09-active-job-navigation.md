# Provider 09 — En Route to Job (Navigation)
Reference: `assets/provider/09_Active_Job_Navigation.png` · Route: `/(provider)/job/[id]/enroute`

**Purpose:** Live navigation to customer with progress tracker.

**Header (blue gradient):** back `‹` + **"En Route to Job"** (white 700) + subtitle **"AC Repair • #SRV1234"** + a white **"📞 Call Customer"** outline button top-right.

**Body:**
1. **Customer card:** avatar with initials **"R"** (tinted blue circle) + **"Rahul Sharma"** (h3); phone **"+91 98765 43210"** + WhatsApp icon; map-pin **"Bodakdev, Ahmedabad"** and full address **"A-702, Shaligram Residency, Bodakdev, Ahmedabad - 380054"** (secondary). Right: **"Open in Maps"** button (light blue, nav icon).
2. **Map** (large, `react-native-maps` or static image): route polyline (blue) from **"Your Location"** (blue dot) to **"Customer Location"** (red pin), a **"12 min / 3.4 km"** callout on the route, zoom +/- and recenter controls, landmarks (SG Highway, IIM Ahmedabad).
3. **ETA stat row** (light rounded panel, 3 cols): car icon **"12 min / ETA"** · **"3.4 km / Distance"** · **"5:00 PM / Expected Arrival"**.
4. **Job mini-card:** AC icon + **"AC Repair"** + **"Split AC not cooling properly"** + right green pill **"On the way"**.
5. **"Job Progress"** (h3) + **"1 of 4"** right. **JobProgress stepper:** En Route (green check, 4:48 PM) → Arrive (2, `--:--`) → In Progress (3) → Complete (4).

**Sticky bottom (two buttons):** **OutlineButton "⚠ Report Issue"** (red) + blue **PrimaryButton "✓ Arrived at Location"** → Job In Progress (10).
