# Provider 12 — Earnings
Reference: `assets/provider/12_Earnings.png` · Route: `/(provider)/(tabs)/earnings` · **Tab: Earnings**

**Purpose:** Income summary, chart, withdraw, transactions.

**Header (blue gradient):** **"Earnings"** (white 700) + subtitle **"Track your income and payouts"** + a **"This Month ⌄"** dropdown pill top-right.

**Body (white sheet, scroll):**
1. **Summary row:** left block **"Total Earnings"** + big **"₹12,480"** (navy 800) + green **"↗ +18% from last month"**. Right: a light-green **Available Balance** card — wallet icon + **"Available Balance / ₹8,320"** + green **SuccessButton "Withdraw"**.
2. **StatTile row (4):** briefcase **"24 / Jobs Completed"** · rupee **"₹520 / Avg. per Job"** · star **"4.8 / Customer Rating"** · people **"18 / Repeat Customers"**.
3. **"Earnings Overview"** (h3) + a small segmented control **`Week` `Month` `Year`** (Month selected, blue).
   - **Bar chart** (4 blue bars), y-axis 0–8K: Week 1 ₹2,400 · Week 2 ₹3,800 · Week 3 ₹2,950 · Week 4 ₹3,330 (value labels above bars).
   - Build with `react-native-svg` / a simple bar chart; bars in `primary` blue, rounded tops.
4. **"Recent Transactions"** (h3) + **"View All ›"** right. List rows: round rupee icon (category color) + **"Service - Customer"** + date; right: green **"+ ₹NNN"** + **"Completed"**.
   - AC Repair - Rahul Sharma · May 20, 2024 · +₹450 · Completed
   - Plumbing - Amit Shah · May 19, 2024 · +₹300 · Completed
   - Electrical - Neha Patel · May 18, 2024 · +₹400 · Completed
   - Carpenter - Kunal Mehta · May 17, 2024 · +₹600 · Completed

**Bottom tab bar:** Home · Leads · Jobs · **Earnings (active, blue)** · Profile.
