# Provider 14 — My Schedule
Reference: `assets/provider/14_My_Schedule.png` · Route: `/(provider)/(tabs)/schedule` · **Tab: Schedule**

**Purpose:** Day-wise job schedule + availability.

**Header (blue gradient):** **"My Schedule"** (white 700) + subtitle **"Manage your jobs and availability"** + a white **"📅 Today"** pill and **⋮** menu top-right.

**Body (white sheet):**
1. **Week strip:** 7 day columns Mon 19 … Sun 25, each with weekday label + date; a small **dot** under days that have jobs (green = has jobs, grey = free). **Thu 22** selected (blue rounded box, white text).
2. Row: **"Thu, 22 May 2024"** (h3 navy) left + **"4 Jobs Scheduled"** (secondary) right.
3. **Timeline job cards** (list). Each: left time block **"10:00 AM / 11:00 AM"** (start/end), then `ServiceIconCircle` + details, right-top a `StatusPill`, chevron-right, and two action buttons:
   - **AC Repair** — Rahul Sharma — Bodakdev, Ahmedabad — "Split AC not cooling properly" — pill **Upcoming** (blue clock) — buttons: outline **"Get Directions"** + blue **"Start Job"**.
   - **Plumbing** (1:00 PM/2:00 PM) — Neha Patel — Vastrapur, Ahmedabad — "Water leakage in kitchen" — pill **Upcoming** — outline **"Get Directions"** + blue **"Start Job"**.
   - **Electrical** (4:00 PM/5:00 PM) — Kishan Makwana — Maninagar, Ahmedabad — "Switch board not working" — pill **Upcoming** — outline **"Get Directions"** + blue **"Start Job"**.
   - **General Service** (6:30 PM/7:30 PM) — Priya Desai — Satellite, Ahmedabad — "Routine AC service" — pill **Scheduled** (grey) — outline **"Get Directions"** + outline **"Contact Customer"** (phone).
4. **"Set Your Availability"** panel (light blue): calendar icon + **"Set Your Availability / Update your working hours and availability"** + chevron.

**Bottom tab bar:** Home · **Schedule (active, blue)** · Jobs · Earnings · Profile.
