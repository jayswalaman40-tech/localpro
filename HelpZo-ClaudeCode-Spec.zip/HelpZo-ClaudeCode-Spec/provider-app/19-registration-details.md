# Provider 19 — Registration: Details (Step 2)
Reference: `assets/provider/19_Registration_Details.png` · Route: `/(provider)/register/details`

**Purpose:** Wizard step 2 — service details + experience + bio.

**Header (blue gradient):** back `‹` + **"Register as Provider"** (white 700) + subtitle **"Join HelpZo and get more work"**.

**Body (white sheet):**
1. **StepIndicator:** 1 Basic (done) — **2 Details** (active blue) — 3 Documents — 4 Complete.
2. **"Service Details"** (h2).
   - Selector row `TextField` (icon + label + chevron): grid icon **"Select Service Category"** / "Choose your primary service" → opens Service & Skills (04).
   - list icon **"Sub Service"** / "Select sub service".
   - map-pin icon **"Service Area"** / "Select your working areas".
3. **"Experience"** (h2).
   - briefcase icon **"Experience (Years)"** / "Select your experience" (selector row).
4. **"About You"** (h2).
   - note icon **"Short Bio"** / "Tell us about yourself (optional)" — multiline field, placeholder **"Enter your short bio..."**, char counter **"0/300"** bottom-right.
5. **PrimaryButton "Next"** (blue) → Documents step (20).
