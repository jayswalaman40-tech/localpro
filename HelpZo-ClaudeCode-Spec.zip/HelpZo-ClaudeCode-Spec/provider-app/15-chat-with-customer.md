# Provider 15 — Chat with Customer
Reference: `assets/provider/15_Chat_with_Customer.png` · Route: `/(provider)/job/[id]/chat`

**Purpose:** 1:1 chat between provider and customer.

**Header (blue gradient):** back `‹` + initials avatar **"R"** + **"Rahul Sharma"** (white 700) + **"Last seen today at 5:32 PM"** (white, lighter) + a white **"📞 Call"** outline button + **⋮** menu top-right.

**Body (chat, white bg, scroll):**
1. **Job context banner** (pinned top card): AC icon + **"AC Repair / Split AC not cooling properly"** + right green pill **"In Progress"** + **"#SRV1234"**.
2. Centered date chip **"Today, 22 May 2024"**.
3. **Message bubbles:**
   - Incoming (left, grey bubble, avatar R): "Hi, I'm Rahul Sharma. My AC is not cooling properly. Can you check and fix it today?" — 9:12 AM
   - Outgoing (right, blue bubble, white text): "Hi Rahul, sure! I am on the way and will reach in about 15 minutes." — 9:15 AM ✓✓
   - Incoming: "Okay, here are some photos of the AC for your reference." — 9:16 AM + a row of 3 image thumbnails (indoor unit, outdoor unit, spec label).
   - Outgoing: "Thanks! I will check this on-site and let you know the exact issue." — 9:17 AM ✓✓
   - Incoming: "Sure. Please bring the gas and check the compressor also." — 9:18 AM
   - Outgoing: "Noted 👍 See you soon." — 9:18 AM ✓✓
   - (double blue ticks ✓✓ on read outgoing messages.)
4. **Quick-reply chips row** (scroll): 👍 **"On my way"** · 🕐 **"Reached"** · ✅ **"Job Completed"** (green) · 📄 **"Share Quote"**.
5. **Input bar:** paperclip (attach) + rounded text field "Type a message..." with emoji icon + blue round **send** button.
