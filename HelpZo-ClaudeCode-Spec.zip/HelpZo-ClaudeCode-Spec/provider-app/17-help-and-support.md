# Provider 17 — Help & Support
Reference: `assets/provider/17_Help_and_Support.png` · Route: `/(provider)/support` · **Tab (5th): Support**

**Purpose:** Support options, FAQ, ticket.

**Header (blue gradient):** back `‹` + **"Help & Support"** (white 700) + subtitle **"We're here to help you"**.

**Body (white sheet, scroll):**
1. **Support banner card:** headset illustration + **"Need help? / Our support team is available 24/7 to assist you."** + right green pill **"● Live Support Available"**.
2. **3 contact tiles** (row, each a Card with chevron): speech-bubble **"Live Chat / Chat with our team"** · phone (green) **"Call Support / +91 1800 123 4567"** · mail (purple) **"Email Us / support@oneapp.com"**.
3. **"Frequently Asked Questions"** (h3) + **"See All"** (blue). Accordion/list rows (chevron-right each):
   - How do I accept a job request?
   - How do I update my availability?
   - When will I receive my payment?
   - How do I cancel a job?
   - What if the customer is not at home?
4. **Two resource rows** (Card): book icon **"Help Center / Browse guides, tutorials and resources"** · play icon (purple) **"Video Tutorials / Watch step-by-step guides"**.
5. **"Still need help?"** panel (light): edit icon + **"Still need help? / Submit a support ticket and we'll get back to you as soon as possible."** + blue **PrimaryButton "Submit Ticket"**.

**Bottom tab bar:** Home · Schedule · Jobs · Earnings · **Support (active, blue headset)**.
