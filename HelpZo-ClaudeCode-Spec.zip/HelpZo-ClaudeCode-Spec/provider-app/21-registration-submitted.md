# Provider 21 — Registration: Submitted (Step 4)
Reference: `assets/provider/21_Registration_Submitted.png` · Route: `/(provider)/register/submitted`

**Purpose:** Wizard step 4 — confirmation, under review.

**Header (blue gradient):** back `‹` + **"Register as Provider"** (white 700) + subtitle **"Join HelpZo and get more work"**.

**Body (white sheet, centered):**
1. **StepIndicator:** 1 Basic — 2 Details — 3 Documents (all done) — **4 Complete** (active blue).
2. **Illustration:** a document/check icon inside a soft green circle with confetti bits (green check badge).
3. **"Registration Submitted!"** (h1 navy 700, centered) + **"Your documents are under verification."** (secondary, centered).
4. **Info steps panel** (light green, vertical timeline with connected green icon nodes):
   - clock — **"We'll review your documents"** / "This usually takes 24–48 hours"
   - mail — **"You'll get a notification"** / "We'll notify you once verified"
   - user — **"Start getting work"** / "After verification, you can start receiving service requests"
5. **PrimaryButton "Go to Dashboard"** (blue) → Active Jobs (06).
