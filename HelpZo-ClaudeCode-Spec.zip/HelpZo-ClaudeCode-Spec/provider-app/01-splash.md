# Provider 01 — Splash Screen
Reference: `assets/provider/01_Splash_Screen.png` · Route: `/(provider)/splash` (initial)

**Purpose:** Provider brand splash. Auto → Login (02) after ~2s.

**Background:** deep solid blue (`primaryDeep`/`primary`), with green+blue **wave** decoration across the bottom.

**Layout (centered):**
1. **HelpZo logo** mark + wordmark ("Help" white, "Zo" green), large.
2. Tagline **"Work Smart • Earn More"** (white, 15).
3. Illustration: **smiling technician in blue overalls + cap holding a wrench** over a faint house silhouette.
4. Lower: **"Provider App"** (white, 20, 700) + **"Grow Your Business"** (white, 14) centered.

No back. Auto navigate to Login (02).
