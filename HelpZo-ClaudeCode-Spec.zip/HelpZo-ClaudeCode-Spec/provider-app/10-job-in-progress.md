# Provider 10 — Job In Progress
Reference: `assets/provider/10_Job_In_Progress.png` · Route: `/(provider)/job/[id]/progress`

**Purpose:** Active on-site job — timer, work notes, service items, signature.

**Header (blue gradient):** back `‹` + **"Job In Progress"** (white 700) + subtitle **"AC Repair • #SRV1234"** + **⋮** menu top-right.

**Body (white sheet, scroll):**
1. **Customer card:** initials avatar **"R"** + **"Rahul Sharma"**; phone + WhatsApp; address (as screen 09). Right: **"Open in Maps"** (light blue).
2. **Job card:** AC icon + **"AC Repair"** + **"Split AC not cooling properly"**; right green pill **"In Progress"** + **"Started at 5:12 PM"** (secondary).
   - **JobProgress stepper:** En Route ✓ (4:48 PM) — Arrived ✓ (5:12 PM) — **In Progress** (blue node 3) — Complete (grey 4).
3. **Job Timer** panel (light green): clock icon + **"Job Timer / Actual time on site"** + big green **"00:28:15"** on the right.
4. **"Work Update"** (h3) + a bordered note box (multiline): *"Checked gas pressure. Found low cooling due to gas leakage. Need to refill gas and replace service valve."*
5. Two buttons row: **OutlineButton "📷 Add Photos"** + **OutlineButton "📎 Add Notes"** (blue outline).
6. **"Service Items"** (h3) — checklist, 2 columns of checkboxes:
   - ☑ Diagnosis / Inspection   ☐ Service Valve Replacement
   - ☑ Gas Refill              ☐ General Cleaning
   (checked = blue filled checkbox)
7. **"Customer Signature"** (h3) + **"Clear"** link right. A grey signature pad box showing a handwritten signature **"Rahul Sharma"**. Caption below (secondary, centered): "Ask customer to sign after service completion".

**Sticky bottom (two buttons):** **OutlineButton "⚠ Mark as Issue"** (red) + green **SuccessButton "✓ Complete Job"** → Job Completed (11).
