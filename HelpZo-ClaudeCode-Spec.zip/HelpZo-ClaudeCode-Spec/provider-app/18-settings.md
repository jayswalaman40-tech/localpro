# Provider 18 — Settings
Reference: `assets/provider/18_Settings.png` · Route: `/(provider)/settings` · **Tab (5th): Settings**

**Purpose:** Account + app preferences.

**Header (blue gradient):** back `‹` + **"Settings"** (white 700) + subtitle **"Manage your account and preferences"**.

**Body (white sheet, scroll):**
1. **Profile card:** avatar (with small camera badge) + **"Aman Sharma"** (h3) + **"Service Professional"** + `RatingRow` ★4.8 (124 reviews) + green **"✓ Verified"** pill; chevron-right.
2. **"Account Settings"** (h2) — list rows (icon + title 600 + subtitle secondary + chevron):
   - user — **"Edit Profile"** / "Update your personal and professional details"
   - id-card (blue) — **"KYC & Verification"** / "Manage your documents" — right green **"✓ Verified"** pill
   - bank — **"Bank & Payouts"** / "Manage payment methods"
   - shield — **"Password & Security"** / "Update your password and security settings"
3. **"App Preferences"** (h2):
   - bell — **"Notifications"** / "Manage your notification preferences" (chevron)
   - globe — **"Language"** / "Choose your preferred language" — right **"English ›"**
   - moon — **"Dark Mode"** / "Switch between light and dark theme" — right **toggle switch (off)**
   - map-pin — **"Location"** / "Manage your location settings" (chevron)
4. **"About"** (h2):
   - info — **"About App"** / "Version 1.0.0"
   - file — **"Terms & Conditions"**
   - shield — **"Privacy Policy"**
5. **Logout** — full-width **OutlineButton** red border + red **"⎋ Logout"**.

**Bottom tab bar:** Home · Schedule · Jobs · Earnings · **Settings (active, blue gear)**.
