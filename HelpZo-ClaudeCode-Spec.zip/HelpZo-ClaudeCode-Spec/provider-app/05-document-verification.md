# Provider 05 — Document Verification (verified state)
Reference: `assets/provider/05_Document_Verification.png` · Route: `/(provider)/register/verification`

**Purpose:** KYC documents list showing verified status. (Post-upload state.)

**Header (blue gradient):** back `‹` + **"Document Verification"** (white 700) + subtitle **"Upload your KYC documents to get verified"**.

**Body (white sheet):**
1. Four **document rows** (Card each): leading `IconTile` (tinted square), title (h3 navy) + subtitle (secondary), and a right-side **green "Verified" pill** + chevron-right.
   - blue id-card tile — **"Aadhaar Card"** / "Front & Back" — **Verified**
   - blue id-card tile — **"PAN Card"** / "Front" — **Verified**
   - avatar tile — **"Selfie with Aadhaar"** / "Live Photo" — **Verified**
   - amber bank tile — **"Bank Details"** / "Cancel Cheque / Passbook" — **Verified**
2. **Success banner** (light green panel, radius 16): green shield-check icon + **"Your Documents are Verified"** (navy 700) + **"You can now start receiving leads."** (secondary).
3. **PrimaryButton "Continue"** (blue) → dashboard (06) / next step.
