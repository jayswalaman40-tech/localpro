# Provider 16 — Reviews & Ratings
Reference: `assets/provider/16_Reviews_and_Ratings.png` · Route: `/(provider)/reviews` · **Tab (5th): Reviews**

**Purpose:** Provider's rating summary + review list.

**Header (blue gradient):** back `‹` + **"Reviews & Ratings"** (white 700) + subtitle **"See what customers say about your service"**.

**Body (white sheet, scroll):**
1. **Summary card:** left — big **"4.8"** (h1 navy) + 4.5 gold stars + **"Based on 124 reviews"** (secondary). Right — **rating distribution bars** 5→1, each: star count label + horizontal bar (blue fill on grey track) + count right:
   - 5★ ▓▓▓▓▓ 96 · 4★ ▓▓ 18 · 3★ ▓ 6 · 2★ ▏3 · 1★ ▏1.
2. **Filter chips row:** **`All (124)`** (selected blue) · `5★ (96)` · `4★ (18)` · `3★ (6)` · `2★ (3)` · `1★ (1)`.
3. **Review cards** (list). Each: initials avatar (tinted), **Name** (h3), star row, **time ago** (right), review text, then a row of small grey **tag chips**:
   - **Rahul Sharma** ★★★★★ · 2 days ago — "Great service! Very professional and on time. My AC is working perfectly now. Highly recommended!" — tags: On Time · Professional · Good Communication
   - **Neha Patel** ★★★★★ · 1 week ago — "Very polite and skilled. Fixed the plumbing issue quickly. Will definitely call again." — tags: Quick Service · Knowledgeable · Polite
   - **Kishan Makwana** ★★★★☆ · 2 weeks ago — "Good work overall. Arrived a bit late but the job was done well." — tags: Good Quality · Late Arrival
   - **Priya Desai** ★★★★★ · 3 weeks ago — "Excellent service! Fixed the electrical issue and explained everything clearly. Very happy!" — tags: Professional · Explained Well · Value for Money
   - **Amit Mehta** ★★★★★ · 1 month ago — "Reliable and trustworthy. Completed the job neatly." — tags: Trustworthy · Neat Work
4. **Encouragement banner** (light blue): trophy icon + **"You're doing great! / Keep providing excellent service to get more reviews and grow your business."** + blue **"⤴ Share Profile"** button.

**Bottom tab bar:** Home · Schedule · Jobs · Earnings · **Reviews (active, blue star)**.
