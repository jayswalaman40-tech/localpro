# Provider 11 — Job Completed
Reference: `assets/provider/11_Job_Completed.png` · Route: `/(provider)/job/[id]/completed`

**Purpose:** Completion summary with itemized bill, payment, rating.

**Header (blue gradient):** back `‹` + **"Job Completed"** (white 700) + subtitle **"AC Repair • #SRV1234"**.

**Body (white sheet, scroll):**
1. **Success hero:** large green **check circle** with confetti bits; **"Job Completed!"** (h1 navy 700, centered) + **"Service has been successfully completed."** (secondary, centered).
2. **Customer card:** initials avatar **"R"** + **"Rahul Sharma"**; phone + WhatsApp; address.
3. **Job card:** AC icon + **"AC Repair"** + **"Split AC not cooling properly"**; right green pill **"✓ Completed"** + **"May 20, 2024 / 5:52 PM"**.
   - **Photo strip:** 4 thumbnails labelled **Before**, **After**, **Service Work**, **Outdoor Unit**; last shows a **"+2"** overlay.
4. **"Service Details"** (h3) — itemized list, each row: green check + item + amount right:
   - Diagnosis / Inspection — ₹0
   - Gas Refill (R32) — ₹850
   - Service Valve Replacement — ₹350
   - General Cleaning — ₹200
   - Divider, then **"Total Amount"** (navy 700) — **"₹1,400"** (navy 700).
5. **Payment Status** panel: green wallet icon + **"Payment Status / Paid via UPI / May 20, 2024, 5:55 PM"** + right green pill **"✓ Paid"** and **"View Receipt ›"** link.
6. **Customer Rating** panel: gold star icon + **"Customer Rating"** + 5 gold stars **"5.0"**; quote *"Great service! Very professional and on time."*; **"View Feedback ›"** link.

**Sticky bottom (two buttons):** **OutlineButton "🏠 Back to Home"** (blue) + blue **PrimaryButton "Next Job ›"**.
