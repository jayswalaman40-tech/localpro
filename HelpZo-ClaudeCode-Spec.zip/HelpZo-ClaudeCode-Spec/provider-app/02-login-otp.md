# Provider 02 — Login / OTP
Reference: `assets/provider/02_Login_OTP.png` · Route: `/(provider)/login`

**Purpose:** Provider phone login.

**Background:** white; bottom has green→blue **wave** decoration.

**Layout (centered, padding 16):**
1. Back `‹` top-left.
2. **HelpZo logo** mark + wordmark centered; under it **"Provider App"** (navy 700).
3. **"Login to Your Account"** (h2 navy 700, left-aligned).
4. **Phone TextField:** 🇮🇳 +91 with chevron-down + divider + placeholder **"Enter Mobile Number"**. Rounded 16, border.
5. **PrimaryButton "Get OTP"** (blue, full width).
6. Legal centered secondary: **"By continuing, you agree to our"** / **"Terms & Conditions  and  Privacy Policy"** (blue links).
7. Bottom over wave: **"New to HelpZo?  Register as Provider"** — "Register as Provider" blue 700 → Registration Basic (03).

**Behavior:** Get OTP → (OTP step, stub) → Active Jobs/Home (06). Register link → wizard step 1 (03).
