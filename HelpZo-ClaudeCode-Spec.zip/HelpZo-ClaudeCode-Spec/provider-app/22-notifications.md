# Provider 22 — Notifications
Reference: `assets/provider/22_Notifications.png` · Route: `/(provider)/notifications` · **Tab (5th): Notifications**

**Purpose:** Provider notification feed with category filters.

**Header (blue gradient):** back `‹` + **"Notifications"** (white 700) + subtitle **"Stay updated with your jobs and activities"** + a **settings gear** icon top-right.

**Body (white sheet):**
1. **Filter chips row (scroll):** **`All (12)`** (selected blue) · `Jobs (5)` · `Payments (3)` · `Messages (2)` · `System (2)`.
2. **Notification rows** (Card each): leading colored icon-circle + **Title** (h3) + 2-line body (secondary) + **time ago** (top-right) + a small **blue unread dot** (right) on unread items:
   - green calendar-check — **"New Job Assigned"** — "You have a new job request for AC Repair in Bodakdev, Ahmedabad." — 2 mins ago • unread
   - blue navigation — **"Customer Reached Location"** — "Rahul Sharma has reached the location. Please start the service." — 15 mins ago • unread
   - amber card — **"Payment Received"** — "You have received ₹1,400 from Rahul Sharma via UPI." — 1 hour ago • unread
   - purple star — **"New Review"** — "Rahul Sharma gave you a 5-star rating. \"Great service! Very professional and on time.\"" — 2 hours ago • unread
   - red alert-triangle — **"Job Issue Reported"** — "Customer reported an issue for Plumbing job in Maninagar." — 5 hours ago
   - green check — **"Job Completed"** — "Your Electrical job at Thaltej has been marked as completed." — 1 day ago
   - blue chat — **"New Message"** — "Neha Patel: \"Can you come tomorrow at 2 PM?\"" — 1 day ago
   - grey bell — **"System Update"** — "New features have been added to improve your experience." — 2 days ago

**Bottom tab bar:** Home · Leads · Jobs · Earnings · **Notifications (active, blue bell with red "3" badge)**.
