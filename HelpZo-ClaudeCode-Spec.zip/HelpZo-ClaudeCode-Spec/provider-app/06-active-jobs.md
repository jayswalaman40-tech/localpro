# Provider 06 — Active Jobs (Dashboard)
Reference: `assets/provider/06_Active_Jobs.png` · Route: `/(provider)/(tabs)/jobs` · **Tab: Jobs**

**Purpose:** Provider's ongoing jobs, manage status. Main dashboard after login.

**Header (blue gradient):** back `‹` + **"Active Jobs"** (white 700) + subtitle **"Manage your ongoing jobs"**.

**Body (white sheet):**
1. **Segment tabs (`Chip` row):** **`Active (5)`** (selected blue) · `Completed (18)` · `Cancelled (3)`.
2. **Search + Filter row:** search `TextField` "Search jobs..." (flex) + a **"Filter"** outline button with funnel icon on the right.
3. **Job cards** (list). Each card:
   - Leading `ServiceIconCircle` (category color).
   - **Service title** (h3 navy) + right-top `StatusPill`.
   - Rows: map-pin **area**; calendar **date/time**; person **customer name**; phone **number** + small **WhatsApp** green icon.
   - Right column of the card: two stacked action buttons (an outline + a solid blue), per status.

**Mock cards:**
1. **AC Repair** — Bodakdev, Ahmedabad — Today, 5:00 PM — Rahul Sharma — +91 98765 43210 — pill **On the way** (green) — buttons: outline **"Get Directions"** (nav icon) + blue **"Update Status"**.
2. **Electrician** — Thaltej, Ahmedabad — Today, 6:30 PM — Neha Patel — +91 91234 56789 — pill **In Progress** (blue) — buttons: outline **"View Details"** + blue **"Mark as Complete"**.
3. **Carpenter** — Vastrapur, Ahmedabad — Tomorrow, 10:00 AM — Kunal Mehta — +91 99887 66554 — pill **Scheduled** (orange) — buttons: outline **"Reschedule"** + blue **"View Details"**.
4. **Cleaning** — Satellite, Ahmedabad — Tomorrow, 2:00 PM — Priya Desai — +91 87654 32109 — pill **Scheduled** (purple) — buttons: outline **"Reschedule"** + blue **"View Details"**.
5. **Plumbing** — Maninagar, Ahmedabad — May 21, 2024, 11:00 AM — Amit Shah — +91 90909 12345 — pill **Scheduled** (orange) — buttons: outline **"Reschedule"** + blue **"View Details"**.

**Bottom tab bar (5):** Home · Leads · **Jobs (active, blue)** · Earnings · Profile.
