# HelpZo — Design System

> This is the single source of truth for colors, typography, spacing and shared
> components. Build these as reusable components/theme tokens FIRST, before any
> screen. Every screen spec refers back to the tokens defined here. Match values
> exactly.

Both apps (Customer + Provider) share this design language. Only the accent
usage differs slightly (Provider leans more on solid blue headers).

---

## 1. Brand

- **App name:** HelpZo — written as **Help** (blue) + **Zo** (green), always one word, no space.
- **Tagline (customer):** "Your Problem, Our Priority"
- **Tagline (provider):** "Work Smart • Earn More"
- **Logo:** house outline with a wrench + magnifier forming the roof. "Help" in blue, "Zo" in green.
- **Language:** English UI. Currency is Indian Rupee `₹`. Locale India (phone `+91`, cities like Ahmedabad).

---

## 2. Color tokens

Define these once in a `theme/colors.ts` file. Hex values are matched to the screenshots.

### Core
| Token | Hex | Usage |
|---|---|---|
| `primary` | `#1667E8` | Primary blue — buttons, active tab, links, selected chips |
| `primaryDark` | `#0B3E9E` | Header gradient top, pressed states |
| `primaryDeep` | `#062B7A` | Splash background base (provider) |
| `secondary` / `success` | `#22B24C` | Green CTA (Book Now, Confirm, Accept), success, positive |
| `secondaryDark` | `#1B9E3E` | Green pressed / success text |
| `danger` | `#E53935` | Reject, Logout, errors |
| `warning` | `#F5A623` | Pending status, alert icons |

### Neutrals
| Token | Hex | Usage |
|---|---|---|
| `bg` | `#FFFFFF` | Screen background (most screens) |
| `bgMuted` | `#F5F7FA` | Alt background, input fill, section separators |
| `card` | `#FFFFFF` | Card surface |
| `cardBorder` | `#EDEFF3` | 1px card / input border |
| `textPrimary` | `#0F2547` | Headings, primary text (dark navy) |
| `textSecondary` | `#6B7280` | Sub text, captions, placeholders |
| `textTertiary` | `#9AA3B2` | Meta (time ago, hints) |
| `star` | `#F6B01E` | Rating star fill |
| `whatsapp` | `#25D366` | WhatsApp round icon |
| `verified` | `#1D9BF0` | Blue verified check badge |

### Status pill colors (bg / text)
| Status | bg | text |
|---|---|---|
| Confirmed / Verified / Completed / Paid | `#D9F5E1` | `#1B9E3E` |
| Pending / Scheduled (warm) | `#FFEBCC` | `#E08A1E` |
| In Progress | `#DCE8FF` | `#1667E8` |
| Scheduled (cool/purple) | `#ECDDFB` | `#8B44D6` |
| On the way | `#D9F5E1` | `#1B9E3E` |
| New Request | `#D9F5E1` | `#1B9E3E` |

### Service category icon colors (circular icon backgrounds)
Used on home grid, provider skills, list avatars.
| Category | bg | icon |
|---|---|---|
| Plumber | `#2680EB` | white water-drop / pipe |
| Electrician | `#F5A623` | white lightning bolt |
| AC Repair | `#4FC3F7` | white snowflake / AC unit |
| Carpenter | `#8B5E3C` | white crossed tools |
| Painter | `#C724B1` | white roller/brush |
| Cleaning | `#2E9E5B` | white broom |
| Home Repair | `#F5821F` | white house |
| More | `#B8C0CC` | white 3-dots |

### Header gradient
Provider headers and customer sub-headers use a vertical blue gradient:
`linear-gradient(180deg, #0B3E9E 0%, #1667E8 100%)` with white text. On the
customer Home the header top strip is `#1667E8`.

---

## 3. Typography

Font family: **Inter** (or system `SF Pro` / `Roboto` fallback). Weights used: 400, 500, 600, 700, 800.

| Style | Size | Weight | Color | Use |
|---|---|---|---|---|
| `display` | 30–34 | 800 | brand | Logo wordmark, splash |
| `h1` | 22 | 700 | textPrimary | Screen title in header |
| `h2` | 18–20 | 700 | textPrimary | Section titles ("Popular Services") |
| `h3` | 16 | 700 | textPrimary | Card name / list item title |
| `body` | 14–15 | 400/500 | textPrimary | Body text |
| `bodySecondary` | 13–14 | 400 | textSecondary | Sub text, descriptions |
| `caption` | 12 | 400 | textTertiary | Meta, timestamps |
| `button` | 16 | 700 | white | Button labels |
| `price` | 15–16 | 700 | textPrimary / green | Prices `₹200 onwards` |

Header titles are white when on blue header, navy when on white header.

---

## 4. Spacing & layout

- Base unit: **4**. Common spacings: 4, 8, 12, 16, 20, 24, 32.
- **Screen horizontal padding:** 16px.
- **Card padding:** 16px. **Gap between cards:** 12–16px.
- **Corner radius:** inputs/buttons/cards `16`, small chips/pills `20` (fully rounded), round icon circles `full`, avatars `full` (list) or `16` (large).
- **Card shadow:** very soft — `shadowColor #0F2547, opacity 0.06, radius 12, y 4`, or a 1px `cardBorder` on flat cards. Keep it subtle.
- **Safe area:** respect notch. Status bar shows `9:41` mock time in designs — real app uses live status bar.
- **Screen size reference:** designs are 1080×2340-ish (modern Android phone, ~19.5:9). Design for 390–430 dp width.

---

## 5. Shared components

Build these as reusable components. Screen specs reference them by name.

### `AppHeader`
- Two variants: **blue** (white bg text on gradient, used on provider + deep screens) and **light** (white bg, navy text, used on customer home).
- Left: back chevron `‹` (navigable screens) OR logo (home/login).
- Center/left-aligned title (`h1`) + optional subtitle line (`bodySecondary`, lighter).
- Right: optional action (bell icon w/ red dot, settings gear, "Edit Profile" pill, filter icon).
- Bottom corners of blue header curve into the white body: header has `borderBottomLeftRadius/RightRadius: 24` OR the white content sheet overlaps with a top radius of 24. (See provider screens — white sheet sits on blue with rounded top.)

### `PrimaryButton` (blue)
- bg `primary`, text white `button`, radius 16, height 52, full width, centered label. Pressed → `primaryDark`.

### `SuccessButton` (green)
- bg `secondary`, white text. Same metrics. Used for Book Now / Confirm / Accept / Complete Job.

### `OutlineButton`
- transparent bg, 1.5px border (color = `primary`, `secondary`, or `danger` depending on context), text same color as border, radius 16. Used for Reject (danger), Call (green), Get Directions (blue), Reschedule (blue).

### `Chip` / `FilterTab`
- Pill radius 20, height ~40, horizontal padding 16.
- Selected: bg `primary`, white text. Unselected: bg white, `cardBorder`, `textSecondary` text.
- Used for filter rows (All / Top Rated / Nearest), booking tabs (Upcoming/Completed/Cancelled), date/time slots.

### `StatusPill`
- Small pill radius 20, tiny padding (h 6, v 3), 12px 600 text, colors from status table above.

### `Card`
- bg white, radius 16, 1px `cardBorder` (or soft shadow), padding 16.

### `Avatar`
- Circle. Sizes: 40 (list small), 56 (list), 64 (profile row), 96 (profile header). Placeholder initials on tinted circle when no photo (e.g. `RS` on light blue) — used in chat/notifications.

### `RatingRow`
- Star icon (`star` color) + bold number + `(N reviews)` in secondary. e.g. `★ 4.8 (124 reviews)`.

### `ServiceIconCircle`
- Circle 56–64, bg = category color, white glyph centered. Label below in `h3`/`body`.

### `BottomTabBar`
- White bg, top hairline border `cardBorder`, 5 (provider) or 4 (customer) items.
- Each: icon + label. Active = `primary` (filled icon + blue label), inactive = `textSecondary` (outline icon).
- Provider tab bar changes label set per section (see navigation.md) — keep a single component, pass the active route.

### `IconTile` (small)
- Rounded-square (radius 12) tinted background with a colored/blue glyph — used for KYC document rows, job category icon on cards, quick-action tiles. bg is a 12% tint of the glyph color.

### `TextField`
- Height 56 for icon fields, radius 16, 1px `cardBorder`, bg white or `bgMuted`.
- Optional leading icon in a rounded tile, label (600) + placeholder (secondary) stacked, or single-line input.

### `SectionTitle`
- `h2` left, optional "See All" link (`primary`, 14, 600) right-aligned on same row.

### `StepIndicator` (registration)
- 4 numbered circles connected by a line. Current = filled `primary` white number; done = filled; future = `bgMuted` circle with `textSecondary` number. Labels under: Basic / Details / Documents / Complete.

### `ProgressBar`
- Rounded track `bgMuted`, fill `secondary` (green). Used for "Complete Profile 80%".

### `Stepper` / `JobProgress`
- Horizontal 4-node tracker: En Route → Arrive → In Progress → Complete. Done nodes green with check, current node blue with number, future grey. Time under each node.

### `StatTile`
- Small card with icon top, big number, label below. Used in Earnings + Profile stat rows (2×2 or 1×4).

---

## 6. Icons

Use **lucide-react-native** (or Ionicons). Common glyphs: chevron-left, chevron-right, bell, search, heart / heart-filled, map-pin, clock, calendar, phone, star, shield-check, wallet, headset, settings, edit-2 (pencil), log-out, camera, paperclip, send, navigation (arrow), check-circle, alert-triangle. WhatsApp uses its brand glyph in a `#25D366` circle.

---

## 7. Global rules for Claude Code

1. Pixel-match the screenshots in `assets/`. When a value isn't in a spec, read the reference image.
2. Every screen uses `SafeAreaView`, screen padding 16, and the shared components above.
3. Use mock/static data exactly as written in each screen spec (names, prices, ratings) so the built screens look identical to the designs.
4. All screens are static UI first (no backend). Wire navigation between them per `navigation.md`. Backend/API is a later phase.
5. Keep both apps in one repo as two Expo entry points (or two `app/` route groups) sharing `theme/` and `components/`. See `CLAUDE.md`.
