# HelpZo — Claude Code Build Spec 📦

Aman, ye package tumhe **Claude Code** ko dena hai. Isme dono HelpZo apps
(Customer + Provider) ke saare screens ka exact spec hai, taaki Claude Code
**bilkul same** screens bana sake — React Native (Expo) me, jisse **APK** build
ho jaye.

## Kaise use karna hai (steps)

1. Is poore folder ko ek jagah rakho (ya GitHub repo bana lo).
2. Us folder me **Claude Code** kholo.
3. Claude Code ko ye bolo:
   > "Read CLAUDE.md and design-system.md first. Then build the Expo app exactly
   > per the screen specs in customer-app/ and provider-app/, matching the
   > screenshots in assets/. Start with the theme and shared components, then
   > build all screens. Finally set up EAS to produce an Android APK."
4. Claude Code pehle theme + components banayega, phir screen-by-screen UI.
5. APK ke liye `CLAUDE.md` ke "Producing the APK" section follow karega (EAS Build).

## Package me kya hai

```
HelpZo-ClaudeCode-Spec/
├── README.md              ← ye file (tumhare liye)
├── CLAUDE.md              ← Claude Code sabse pehle isko padhega (stack + build + APK)
├── design-system.md       ← colors, fonts, spacing, shared components (foundation)
├── navigation.md          ← dono apps ka tab bar + screen flow
├── customer-app/          ← 10 screen specs (customer app)
│   ├── 01-splash.md ... 10-profile.md
├── provider-app/          ← 22 screen specs (provider app)
│   ├── 01-splash.md ... 22-notifications.md
└── assets/
    ├── customer/          ← 10 reference screenshots
    └── provider/          ← 22 reference screenshots
```

Har screen spec ka naam uske screenshot se match karta hai
(e.g. `provider-app/12-earnings.md` ↔ `assets/provider/12_Earnings.png`).
Claude Code build karte waqt spec + screenshot dono use karega, isliye pixel-match hoga.

## Apps ka summary

**HelpZo Customer App (10 screens)** — user service dhoondhta, provider book karta:
Splash → Login/OTP → Home (search + categories + top providers) → Provider List →
Provider Profile → Book Service → My Bookings → Saved → Notifications → Profile.

**HelpZo Provider App (22 screens)** — service professional kaam manage karta:
Splash → Login → 4-step Registration (Basic → Details → Documents → Submitted) +
Service/Skills + KYC → Active Jobs → New Leads → Job Details → En Route (map) →
Job In Progress → Job Completed → Earnings → Profile → Schedule → Chat → Reviews →
Help → Settings → Notifications.

## Tech (CLAUDE.md me detail hai)
- React Native + **Expo** + TypeScript
- expo-router (navigation), lucide icons, Inter font
- Phase 1 = static UI (mock data spec me diya hai). Backend baad me.
- APK = **EAS Build** (`eas build -p android --profile preview`, buildType `apk`)

## Ek zaroori tip
Dono apps ek hi repo me rakho (shared `theme/` + `components/`), lekin do alag
entry points/package-id se — taaki do alag APK ban sakein:
`com.helpzo.customer` aur `com.helpzo.provider`.

Design tokens (`design-system.md`) me approximate hex diye hain screenshots se —
agar tumhare paas exact brand hex hain to bas wahi file update kar dena, baaki
sab wahi tokens use karta hai.
